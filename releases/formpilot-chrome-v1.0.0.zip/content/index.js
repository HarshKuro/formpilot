import{c as D,r as z,j as o,S as K,b as U,g as H}from"../chunks/shield-check-BUR2WuxU.js";import{C as W}from"../chunks/circle-check-DZsI1h5X.js";import{E as B}from"../chunks/external-link-DvepNmXX.js";/**
 * @license lucide-react v1.65.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q={name:"sparkles",size:24,node:[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],aliases:["stars"]};q.node;const G=D(q);/**
 * @license lucide-react v1.65.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R={name:"x",size:24,node:[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]};R.node;const Q=D(R);function V(e=typeof window<"u"?window.location.href:""){if(!e)return!1;try{const t=new URL(e);return t.hostname!=="docs.google.com"?!1:t.pathname.startsWith("/forms/")}catch{return!1}}function L(e){return e?e.replace(/\*/g,"").replace(/\u00A0/g," ").replace(/Your answer/gi,"").replace(/Required/gi,"").replace(/\s+/g," ").trim():""}function $(e,t=[]){const r=e.toLowerCase(),n=["consent","declaration","important message","agree","confirm that","terms","responsibility","undertaking","acknowledgement","acknowledge"];if(n.some(a=>r.includes(a)))return!0;for(const a of t){const s=a.label.toLowerCase();if(n.some(d=>s.includes(d)))return!0}return!1}function P(e=document){var a,s,d,l;const t=[],r=Array.from(e.querySelectorAll('div.Qr7Oae, div[role="listitem"]'));let n=1;for(const i of r){let u="",c="";const b=i.querySelector("span.M7eMe, .M7eMe");if(b)c=b.textContent||"",u=L(c);else{const p=i.querySelector('div[role="heading"], div.geS5n, [aria-level="3"]');p&&(c=p.textContent||"",u=L(c))}if(!u)continue;const y=!!(i.querySelector('[aria-label*="Required"]')||i.querySelector('[aria-label*="required"]')||i.querySelector(".v5Duua")||c.includes("*"));let w="unsupported",N;const k=[],A=Array.from(i.querySelectorAll('div[role="radio"]'));if(A.length>0){w="radio";for(const p of A){const f=p.getAttribute("data-value"),x=p.getAttribute("aria-label"),g=(s=(a=p.closest(".docssharedWizToggleLabeledContainer"))==null?void 0:a.querySelector(".docssharedWizToggleLabeledLabelText"))==null?void 0:s.textContent,h=(f||x||g||p.textContent||"").replace(/\u00A0/g," ").trim();k.push({value:f||h,label:h,element:p})}}else{const p=Array.from(i.querySelectorAll('div[role="checkbox"]'));if(p.length>0){w="checkbox";for(const f of p){const x=f.getAttribute("data-value"),g=f.getAttribute("aria-label"),h=(l=(d=f.closest(".docssharedWizToggleLabeledContainer"))==null?void 0:d.querySelector(".docssharedWizToggleLabeledLabelText"))==null?void 0:l.textContent,O=(x||g||h||f.textContent||"").replace(/\u00A0/g," ").trim();k.push({value:x||O,label:O,element:f})}}else{const f=i.querySelector('div[role="listbox"]');if(f){w="dropdown",N=f;const x=Array.from(i.querySelectorAll('div[role="option"]'));for(const g of x){const h=(g.textContent||g.getAttribute("data-value")||"").trim();k.push({value:g.getAttribute("data-value")||h,label:h,element:g})}}else{const x=i.querySelector('input[type="date"]');if(x)w="date",N=x;else{const g=i.querySelector("textarea.KHxj8b, textarea");if(g)w="paragraph",N=g;else{const h=i.querySelector('input[type="text"].whsOnd, input[type="text"]');h&&(w="text",N=h)}}}}}const _=$(u,k);t.push({id:`formpilot-q-${n++}`,title:u,rawTitle:c,controlType:w,containerElement:i,inputElement:N,options:k.length>0?k:void 0,isRequired:y,isConsentOrDeclaration:_})}return t}let S=null,j=null;function X(e,t=300,r=document.body){v();const n=P(document);return e(n),S=new MutationObserver(a=>{let s=!1;for(const d of a)if(d.type==="childList"&&(d.addedNodes.length>0||d.removedNodes.length>0)){s=!0;break}s&&(j&&clearTimeout(j),j=setTimeout(()=>{const d=P(document);e(d)},t))}),S.observe(r,{childList:!0,subtree:!0}),v}function v(){j&&(clearTimeout(j),j=null),S&&(S.disconnect(),S=null)}function Y(e){return e?e.toLowerCase().replace(/[*\-_/\\()[\],.:;?]/g," ").replace(/%/g," % ").replace(/\s+/g," ").trim():""}function T(e){return e?e.toLowerCase().replace(/[.\-_/\\()[\],:;]/g,"").replace(/\s+/g,"").trim():""}const J=["resume","cv","position applying for","job location preference","location preference","preferred location","notice period","expected ctc","current ctc","why should we hire you","cover letter"],I={uid:["uid","roll no","roll number","registration no","registration number","reg no","reg number","student id","enrollment no","enrollment number","university roll no"],name:["name","full name","student name","candidate name","applicant name","name of student","name of candidate"],dateOfBirth:["date of birth","dob","birth date","d o b"],age:["age","age in years","current age","age years"],gender:["gender","sex"],college:["college","university","college name","university name","institute","institute name","institution","name of college","name of university"],currentCourse:["current course","course","degree","program","current degree","pursuing course","course enrolled"],currentStream:["current stream","stream","branch","specialization","specialisation","department","current branch","current specialization"],passingOutBatch:["passing out batch","batch","passing year","year of passing","yop","pass out batch","passout batch","graduating year"],tenthPercentage:["xth %","xth percentage","xth","10th %","10th percentage","10th","tenth percentage","class 10","class 10th","ssc percentage","matriculation percentage","x percentage"],twelfthOrDiplomaPercentage:["best in xiith and diploma %","best in xiith and diploma","xiith %","xiith percentage","xiith","12th %","12th percentage","12th","twelfth percentage","class 12","class 12th","diploma percentage","diploma %","hsc percentage","intermediate percentage","inter percentage","best in 12th and diploma %","xii percentage"],graduationPercentage:["grad %","grad percentage","grad","graduation percentage","graduation %","btech percentage","be percentage","degree percentage","ug percentage","undergraduate percentage"],postGraduationPercentage:["pg %","pg percentage","pg","post graduation percentage","post graduation %","mtech percentage","postgraduate percentage","masters percentage"],currentCourseBacklogs:["backlogs in current course","current course backlogs","backlogs","active backlogs","current backlogs","number of backlogs","standing backlogs","history of backlogs","any backlogs"],currentCgpa:["current cgpa","cgpa","current gpa","gpa","overall cgpa","cumulative gpa"],educationGapMonths:["gap break in education in months","gap break in education","gap in education in months","gap in education","break in education in months","break in education","education gap months","education gap","gap months"],permanentAddress:["permanent address","address","residential address","home address"],mobile:["mobile","mobile number","phone","phone number","contact number","whatsapp number","calling number"],email:["email id","email","email address","official email","college email","personal email"]};function Z(e=[],t){if(!e||e.length===0||!t)return null;const r=T(t);for(const n of e)if(T(n.label)===r||T(n.value)===r)return n;if(r==="aiml"){const n=e.find(a=>{const s=T(a.label);return s==="aiml"||s==="aiml"||s.includes("aiml")||s.includes("ai")&&s.includes("ml")});if(n)return n}if(r==="be"){const n=e.find(a=>T(a.label)==="be");if(n)return n}return null}function ee(e,t){const r=Y(e.title);if(e.isConsentOrDeclaration)return{questionId:e.id,questionTitle:e.title,matched:!1,skipReason:"CONSENT_DECLARATION",confidence:0};for(const c of J)if(r.includes(c))return{questionId:e.id,questionTitle:e.title,matched:!1,skipReason:"MANUAL_FIELD_EXCLUDED",confidence:0};let n=[];const a=/\b(10th|xth|tenth|ssc|matric)\b/i.test(r),s=/\b(12th|xiith|twelfth|diploma|hsc|inter)\b/i.test(r),d=/\b(pg|post grad|post graduation|mtech|masters)\b/i.test(r),l=/\b(grad|graduation|btech|be|undergraduate|ug)\b/i.test(r)&&!d&&!a&&!s;if(a)n=["tenthPercentage"];else if(s)n=["twelfthOrDiplomaPercentage"];else if(d)n=["postGraduationPercentage"];else if(l&&(r.includes("%")||r.includes("percentage")||r.includes("marks")))n=["graduationPercentage"];else for(const[c,b]of Object.entries(I))if(!["tenthPercentage","twelfthOrDiplomaPercentage","graduationPercentage","postGraduationPercentage"].includes(c)){for(const y of b)if(r===y||r.startsWith(y+" ")||r.endsWith(" "+y)||r.includes(" "+y+" ")){n.push(c);break}}if(n.length===0)return{questionId:e.id,questionTitle:e.title,matched:!1,skipReason:"LOW_CONFIDENCE",confidence:0};if(n.length>1){const c=n.find(b=>I[b].includes(r));if(c)n=[c];else return{questionId:e.id,questionTitle:e.title,matched:!1,skipReason:"AMBIGUOUS_MATCH",confidence:.5}}const i=n[0],u=t[i];if(!u||typeof u=="string"&&u.trim()==="")return{questionId:e.id,questionTitle:e.title,matched:!1,fieldKey:i,skipReason:"NO_PROFILE_VALUE",confidence:.9};if(e.controlType==="radio"||e.controlType==="dropdown"){const c=Z(e.options,u);return c?{questionId:e.id,questionTitle:e.title,matched:!0,fieldKey:i,valueToFill:c.value,selectedOption:c,confidence:1}:{questionId:e.id,questionTitle:e.title,matched:!1,fieldKey:i,skipReason:"NO_OPTION_MATCH",confidence:.9}}return{questionId:e.id,questionTitle:e.title,matched:!0,fieldKey:i,valueToFill:u,confidence:1}}function te(e,t){const r=[],n=new Set;for(const a of e){const s=ee(a,t);if(s.matched&&s.fieldKey){if(n.has(s.fieldKey)){r.push({...s,matched:!1,skipReason:"AMBIGUOUS_MATCH",confidence:.5});continue}n.add(s.fieldKey)}r.push(s)}return r}const ne=({matchedCount:e,skippedCount:t,studentName:r,isCompleted:n=!1,filledCount:a=0,onAccept:s,onReject:d,onClose:l,onEdit:i})=>(z.useEffect(()=>{const u=c=>{c.key==="Escape"&&l()};return window.addEventListener("keydown",u),()=>window.removeEventListener("keydown",u)},[l]),o.jsxs("div",{role:"dialog","aria-labelledby":"formpilot-dialog-title","aria-describedby":"formpilot-dialog-desc",className:"fixed bottom-6 right-6 z-[2147483647] w-[340px] bg-white rounded-2xl shadow-2xl border border-slate-200/80 overflow-hidden font-sans text-slate-800 transition-all duration-200 animate-in fade-in slide-in-from-bottom-4",style:{boxShadow:"0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04), 0 0 0 1px rgba(0, 0, 0, 0.05)"},children:[o.jsxs("div",{className:"bg-slate-900 text-white px-4 py-3.5 flex items-center justify-between",children:[o.jsxs("div",{className:"flex items-center space-x-2.5",children:[o.jsx("div",{className:"w-7 h-7 rounded-lg bg-indigo-500 flex items-center justify-center text-white font-black text-sm shadow-inner",children:"FP"}),o.jsxs("div",{children:[o.jsxs("h2",{id:"formpilot-dialog-title",className:"font-semibold text-sm leading-tight text-white flex items-center gap-1.5",children:[o.jsx("span",{children:"FormPilot"}),o.jsx("span",{className:"text-[10px] bg-indigo-900/80 text-indigo-200 px-1.5 py-0.5 rounded font-mono font-normal",children:"Local"})]}),o.jsx("p",{id:"formpilot-dialog-desc",className:"text-[11px] text-slate-300",children:r?`Profile: ${r}`:"Student Profile Autofill"})]})]}),o.jsx("button",{onClick:l,"aria-label":"Close prompt",className:"text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-400",children:o.jsx(Q,{className:"w-4 h-4"})})]}),o.jsx("div",{className:"p-4 space-y-3.5",children:n?o.jsxs("div",{className:"space-y-3",children:[o.jsxs("div",{className:"flex items-center space-x-2.5 text-emerald-700 bg-emerald-50 border border-emerald-100 p-3 rounded-xl",children:[o.jsx(W,{className:"w-5 h-5 flex-shrink-0 text-emerald-600"}),o.jsxs("div",{children:[o.jsx("p",{className:"font-semibold text-xs text-emerald-900",children:"Autofill Complete!"}),o.jsxs("p",{className:"text-[11px] text-emerald-800 mt-0.5",children:[a," questions filled. Please review answers below and submit manually."]})]})]}),o.jsx("button",{onClick:l,className:"w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-slate-400",children:"Done & Dismiss"})]}):o.jsxs(o.Fragment,{children:[o.jsxs("div",{className:"grid grid-cols-2 gap-2 text-center",children:[o.jsxs("div",{className:"bg-indigo-50/70 border border-indigo-100 rounded-xl p-2.5",children:[o.jsx("span",{className:"block text-lg font-bold text-indigo-700 leading-tight",children:e}),o.jsxs("span",{className:"text-[11px] font-medium text-indigo-950",children:[e," fields ready"]})]}),o.jsxs("div",{className:"bg-slate-50 border border-slate-100 rounded-xl p-2.5",children:[o.jsx("span",{className:"block text-lg font-bold text-slate-600 leading-tight",children:t}),o.jsxs("span",{className:"text-[11px] font-medium text-slate-600",children:[t," manual questions"]})]})]}),o.jsx("p",{className:"text-[11px] text-slate-500 leading-relaxed",children:"FormPilot fills only high-confidence profile fields. Manual questions, declaration checkboxes, and resume links remain untouched for you."}),o.jsxs("div",{className:"space-y-2 pt-1",children:[o.jsxs("button",{onClick:s,disabled:e===0,className:`w-full py-2.5 px-4 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 shadow-sm transition-all focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1 ${e>0?"bg-indigo-600 hover:bg-indigo-700 text-white cursor-pointer active:scale-[0.99]":"bg-slate-100 text-slate-400 cursor-not-allowed"}`,children:[o.jsx(G,{className:"w-3.5 h-3.5"}),o.jsxs("span",{children:["Autofill ",e," Fields"]})]}),o.jsxs("div",{className:"grid grid-cols-2 gap-2",children:[o.jsx("button",{onClick:d,className:"py-2 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition-colors text-center focus:outline-none focus:ring-2 focus:ring-slate-400",children:"Reject & Dismiss"}),o.jsxs("button",{onClick:i,className:"py-2 px-2 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium rounded-lg flex items-center justify-center space-x-1 transition-colors text-center focus:outline-none focus:ring-2 focus:ring-slate-400",children:[o.jsx("span",{children:"Edit Profile"}),o.jsx(B,{className:"w-3 h-3 text-slate-400"})]})]})]})]})}),o.jsxs("div",{className:"bg-slate-50 px-4 py-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400",children:[o.jsxs("span",{className:"flex items-center space-x-1",children:[o.jsx(K,{className:"w-3 h-3 text-emerald-600"}),o.jsx("span",{className:"text-slate-600",children:"No cloud transmission"})]}),o.jsx("span",{children:"By Harsh Partap Jain"})]})]})),M="formpilot-root-host";let E=null,m=null;const oe=`
  *, *::before, *::after {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
  .font-sans {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  }
  .fixed { position: fixed; }
  .bottom-6 { bottom: 1.5rem; }
  .right-6 { right: 1.5rem; }
  .w-\\[340px\\] { width: 340px; }
  .w-full { width: 100%; }
  .w-7 { width: 1.75rem; }
  .h-7 { height: 1.75rem; }
  .w-5 { width: 1.25rem; }
  .h-5 { height: 1.25rem; }
  .w-4 { width: 1rem; }
  .h-4 { height: 1rem; }
  .w-3\\.5 { width: 0.875rem; }
  .h-3\\.5 { height: 0.875rem; }
  .w-3 { width: 0.75rem; }
  .h-3 { height: 0.75rem; }
  .rounded-2xl { border-radius: 1rem; }
  .rounded-xl { border-radius: 0.75rem; }
  .rounded-lg { border-radius: 0.5rem; }
  .rounded-md { border-radius: 0.375rem; }
  .rounded { border-radius: 0.25rem; }
  .bg-white { background-color: #ffffff; }
  .bg-slate-900 { background-color: #0f172a; }
  .bg-slate-800 { background-color: #1e293b; }
  .bg-slate-100 { background-color: #f1f5f9; }
  .bg-slate-50 { background-color: #f8fafc; }
  .bg-indigo-600 { background-color: #4f46e5; }
  .bg-indigo-500 { background-color: #6366f1; }
  .bg-indigo-50 { background-color: #eef2ff; }
  .bg-indigo-900\\/80 { background-color: rgba(49, 46, 129, 0.8); }
  .bg-emerald-50 { background-color: #ecfdf5; }
  .text-white { color: #ffffff; }
  .text-slate-800 { color: #1e293b; }
  .text-slate-700 { color: #334155; }
  .text-slate-600 { color: #475569; }
  .text-slate-500 { color: #64748b; }
  .text-slate-400 { color: #94a3b8; }
  .text-slate-300 { color: #cbd5e1; }
  .text-indigo-600 { color: #4f46e5; }
  .text-indigo-700 { color: #4338ca; }
  .text-indigo-950 { color: #1e1b4b; }
  .text-indigo-200 { color: #c7d2fe; }
  .text-emerald-900 { color: #064e3b; }
  .text-emerald-800 { color: #065f46; }
  .text-emerald-700 { color: #047857; }
  .text-emerald-600 { color: #059669; }
  .border { border-width: 1px; border-style: solid; }
  .border-t { border-top-width: 1px; border-top-style: solid; }
  .border-slate-200 { border-color: #e2e8f0; }
  .border-slate-100 { border-color: #f1f5f9; }
  .border-indigo-100 { border-color: #e0e7ff; }
  .border-emerald-100 { border-color: #d1fae5; }
  .p-4 { padding: 1rem; }
  .p-3 { padding: 0.75rem; }
  .p-2\\.5 { padding: 0.625rem; }
  .p-2 { padding: 0.5rem; }
  .p-1 { padding: 0.25rem; }
  .px-4 { padding-left: 1rem; padding-right: 1rem; }
  .py-3\\.5 { padding-top: 0.875rem; padding-bottom: 0.875rem; }
  .py-2\\.5 { padding-top: 0.625rem; padding-bottom: 0.625rem; }
  .py-2 { padding-top: 0.5rem; padding-bottom: 0.5rem; }
  .py-0\\.5 { padding-top: 0.125rem; padding-bottom: 0.125rem; }
  .px-1\\.5 { padding-left: 0.375rem; padding-right: 0.375rem; }
  .flex { display: flex; }
  .grid { display: grid; }
  .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .gap-2 { gap: 0.5rem; }
  .items-center { align-items: center; }
  .justify-between { justify-content: space-between; }
  .justify-center { justify-content: center; }
  .space-x-1 > * + * { margin-left: 0.25rem; }
  .space-x-1\\.5 > * + * { margin-left: 0.375rem; }
  .space-x-2 > * + * { margin-left: 0.5rem; }
  .space-x-2\\.5 > * + * { margin-left: 0.625rem; }
  .space-y-2 > * + * { margin-top: 0.5rem; }
  .space-y-3 > * + * { margin-top: 0.75rem; }
  .space-y-3\\.5 > * + * { margin-top: 0.875rem; }
  .text-sm { font-size: 0.875rem; line-height: 1.25rem; }
  .text-xs { font-size: 0.75rem; line-height: 1rem; }
  .text-lg { font-size: 1.125rem; line-height: 1.75rem; }
  .text-\\[11px\\] { font-size: 11px; line-height: 1rem; }
  .text-\\[10px\\] { font-size: 10px; line-height: 0.875rem; }
  .font-semibold { font-weight: 600; }
  .font-bold { font-weight: 700; }
  .font-black { font-weight: 900; }
  .font-medium { font-weight: 500; }
  .font-mono { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
  .leading-tight { line-height: 1.25; }
  .leading-relaxed { line-height: 1.5; }
  .cursor-pointer { cursor: pointer; }
  .cursor-not-allowed { cursor: not-allowed; }
  .overflow-hidden { overflow: hidden; }
  button {
    border: none;
    font-family: inherit;
    cursor: pointer;
  }
  button:hover {
    filter: brightness(0.96);
  }
`;function F(e){if(!m){const t=document.getElementById(M);t&&t.remove(),m=document.createElement("div"),m.id=M,m.style.position="fixed",m.style.zIndex="2147483647",m.style.bottom="0",m.style.right="0",document.body.appendChild(m);const r=m.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=oe,r.appendChild(n);const a=document.createElement("div");a.id="formpilot-shadow-app",r.appendChild(a),E=U.createRoot(a)}E&&E.render(o.jsx(ne,{...e}))}function C(){E&&(E.unmount(),E=null),m&&(m.remove(),m=null)}function re(e,t,r=!1){var s,d,l,i;if(!e)return!1;const n=e.tagName.toLowerCase();if(n!=="input"&&n!=="textarea")return!1;const a=e;if(!r&&a.value&&a.value.trim().length>0)return!1;try{a.focus();const u=((s=e.ownerDocument)==null?void 0:s.defaultView)||window,c=n==="input"?(d=u.HTMLInputElement)==null?void 0:d.prototype:(l=u.HTMLTextAreaElement)==null?void 0:l.prototype,b=c?(i=Object.getOwnPropertyDescriptor(c,"value"))==null?void 0:i.set:null;return b?b.call(a,t):a.value=t,a.dispatchEvent(new Event("input",{bubbles:!0,cancelable:!0})),a.dispatchEvent(new Event("change",{bubbles:!0,cancelable:!0})),a.blur(),!0}catch(u){return console.error("[FormPilot] Failed to fill text input:",u),!1}}function ie(e){if(!e||!e.element)return!1;try{const t=e.element;return t.focus(),t.click(),t.setAttribute("aria-checked","true"),t.dispatchEvent(new MouseEvent("click",{bubbles:!0,cancelable:!0})),t.dispatchEvent(new Event("change",{bubbles:!0,cancelable:!0})),t.blur(),!0}catch(t){return console.error("[FormPilot] Failed to select radio option:",t),!1}}function ae(e){if(!e||!e.element)return!1;try{const t=e.element;return t.click(),t.dispatchEvent(new MouseEvent("click",{bubbles:!0,cancelable:!0})),!0}catch(t){return console.error("[FormPilot] Failed to select dropdown option:",t),!1}}function se(e,t){let r=0,n=0;const a=[],s=[],d=new Map;for(const l of e)d.set(l.id,l);for(const l of t){if(!l.matched||!l.valueToFill){n++,s.push(l.questionTitle);continue}const i=d.get(l.questionId);if(!i){n++,s.push(l.questionTitle);continue}if(i.isConsentOrDeclaration||l.skipReason==="CONSENT_DECLARATION"||l.skipReason==="MANUAL_FIELD_EXCLUDED"){n++,s.push(l.questionTitle);continue}let u=!1;if(i.controlType==="text"||i.controlType==="paragraph"||i.controlType==="date"){const c=i.inputElement||i.containerElement.querySelector('input[type="text"], textarea');c&&(u=re(c,l.valueToFill))}else i.controlType==="radio"&&l.selectedOption?u=ie(l.selectedOption):i.controlType==="dropdown"&&l.selectedOption&&(u=ae(l.selectedOption));u?(r++,a.push(i.title)):(n++,s.push(i.title))}return{filledCount:r,skippedCount:n,totalCount:e.length,filledFields:a,skippedFields:s}}async function le(){if(!V())return;const e=`formpilot_dismissed_${window.location.pathname}`;if(sessionStorage.getItem(e)==="true")return;const t=await H();if(!t||!t.uid&&!t.name)return;let r=!1,n=0;X(a=>{if(sessionStorage.getItem(e)==="true"){C(),v();return}if(a.length===0)return;const s=te(a,t),d=s.filter(i=>i.matched).length,l=s.filter(i=>!i.matched).length;d===0&&!r||F({matchedCount:d,skippedCount:l,studentName:t.name,isCompleted:r,filledCount:n,onAccept:()=>{const i=se(a,s);r=!0,n=i.filledCount,F({matchedCount:d,skippedCount:l,studentName:t.name,isCompleted:!0,filledCount:i.filledCount,onAccept:()=>{},onReject:()=>{sessionStorage.setItem(e,"true"),C(),v()},onClose:()=>{sessionStorage.setItem(e,"true"),C(),v()},onEdit:()=>{chrome.runtime.sendMessage({action:"OPEN_OPTIONS"})}})},onReject:()=>{sessionStorage.setItem(e,"true"),C(),v()},onClose:()=>{sessionStorage.setItem(e,"true"),C(),v()},onEdit:()=>{chrome.runtime.sendMessage({action:"OPEN_OPTIONS"})}})})}typeof window<"u"&&typeof document<"u"&&le();
